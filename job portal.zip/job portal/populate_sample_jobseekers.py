import sqlite3

# Connect to your database
conn = sqlite3.connect("database.db")
cur = conn.cursor()

# Sample jobseekers
jobseekers = [
    ("Alice Johnson", "alice@example.com", "password123"),
    ("Bob Smith", "bob@example.com", "password123"),
    ("Charlie Lee", "charlie@example.com", "password123"),
    ("Diana Prince", "diana@example.com", "password123"),
    ("Ethan Brown", "ethan@example.com", "password123")
]

# Insert jobseekers into users table
for name, email, password in jobseekers:
    cur.execute("""
    INSERT OR IGNORE INTO users (name, email, password, role)
    VALUES (?, ?, ?, 'jobseeker')
    """, (name, email, password))

conn.commit()
conn.close()
print("Sample jobseeker accounts added successfully!")
