import sqlite3

# Connect to your database
conn = sqlite3.connect("database.db")
cur = conn.cursor()

# Add an employer if not exists
cur.execute("""
INSERT OR IGNORE INTO users (id, name, email, password, role)
VALUES (1, 'Admin Employer', 'employer1@example.com', 'password123', 'employer')
""")

# Sample companies and their jobs
companies_jobs = {
    "TechCorp": [
        ("Software Engineer", "Develop and maintain web applications"),
        ("Frontend Developer", "Build responsive user interfaces"),
        ("Backend Developer", "Develop server-side logic and APIs")
    ],
    "DataSolutions": [
        ("Data Analyst", "Analyze datasets and generate insights"),
        ("Data Scientist", "Build predictive models using machine learning")
    ],
    "MarketMakers": [
        ("Marketing Intern", "Assist in digital marketing campaigns"),
        ("Social Media Manager", "Manage social media accounts and strategy")
    ],
    "WebWorks": [
        ("Fullstack Developer", "Work on both frontend and backend development"),
        ("UI/UX Designer", "Design user-friendly interfaces")
    ],
    "CodeBase": [
        ("DevOps Engineer", "Maintain CI/CD pipelines and cloud infrastructure"),
        ("QA Engineer", "Test software and report bugs")
    ],
    "FinancePlus": [
        ("Financial Analyst", "Analyze financial data and reports"),
        ("Accountant", "Manage company accounts and transactions")
    ],
    "HealthCorp": [
        ("Medical Researcher", "Conduct research on healthcare solutions"),
        ("Lab Technician", "Assist in laboratory experiments and tests")
    ],
    "EduSmart": [
        ("Content Writer", "Create educational content and resources"),
        ("Curriculum Designer", "Design online courses and curricula")
    ],
    "GreenEnergy": [
        ("Project Manager", "Manage renewable energy projects"),
        ("Field Engineer", "Monitor and maintain energy equipment")
    ],
    "TravelEase": [
        ("Travel Consultant", "Assist clients in travel planning"),
        ("Customer Support", "Handle client queries and support")
    ]
}

# Insert jobs into database
for company, jobs in companies_jobs.items():
    for title, description in jobs:
        cur.execute("""
        INSERT INTO jobs (title, description, company, posted_by)
        VALUES (?, ?, ?, ?)
        """, (title, description, company, 1))

conn.commit()
conn.close()
print("10 companies and their jobs have been added successfully!")
