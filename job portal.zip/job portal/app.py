from flask import Flask, render_template, request, redirect, url_for, session, g
import sqlite3, os
from werkzeug.utils import secure_filename

# -------------------- CONFIG --------------------
app = Flask(__name__)
app.secret_key = "supersecretkey"

DATABASE = "database.db"
UPLOAD_FOLDER = "static/resumes"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# -------------------- DATABASE --------------------
def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    # Users
    cur.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT, 
                    email TEXT UNIQUE, 
                    password TEXT, 
                    role TEXT,
                    resume_path TEXT)''')
    # Jobs
    cur.execute('''CREATE TABLE IF NOT EXISTS jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT, 
                    description TEXT, 
                    company TEXT, 
                    posted_by INTEGER)''')
    # Applications
    cur.execute('''CREATE TABLE IF NOT EXISTS applications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id INTEGER, 
                    user_id INTEGER,
                    resume_path TEXT,
                    status TEXT DEFAULT 'Pending')''')
    conn.commit()
    conn.close()

# -------------------- ROUTES --------------------
@app.route("/", methods=["GET", "POST"])
def home():
    conn = get_db_connection()
    cur = conn.cursor()
    if request.method == "POST":
        search = request.form["search"]
        cur.execute("SELECT * FROM jobs WHERE title LIKE ? OR company LIKE ?", 
                    ('%' + search + '%', '%' + search + '%'))
    else:
        cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()
    conn.close()
    return render_template("home.html", jobs=jobs)

# ----------- AUTH -----------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = request.form["password"]
        role = request.form["role"]

        conn = get_db_connection()
        try:
            conn.execute("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
                         (name, email, password, role))
            conn.commit()
        except:
            conn.close()
            return "⚠️ User already exists!"
        conn.close()
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
        user = cur.fetchone()
        conn.close()
        if user:
            session["user_id"] = user["id"]
            session["role"] = user["role"]
            session["username"] = user["name"]  # ✅ Added this line
            return redirect(url_for("home"))
        return "⚠️ Invalid credentials!"
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

# ----------- PROFILE (Resume Upload) -----------
@app.route("/profile", methods=["GET", "POST"])
def profile():
    if not session.get("user_id"):
        return redirect(url_for("login"))

    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == "POST":
        if "resume" not in request.files:
            return "⚠️ No resume uploaded!"
        resume = request.files["resume"]
        if resume.filename == "":
            return "⚠️ Invalid file!"
        filename = secure_filename(resume.filename)
        resume.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))

        cur.execute("UPDATE users SET resume_path=? WHERE id=?", (filename, session["user_id"]))
        conn.commit()
        conn.close()
        return redirect(url_for("profile"))

    cur.execute("SELECT * FROM users WHERE id=?", (session["user_id"],))
    user = cur.fetchone()
    conn.close()
    return render_template("profile.html", user=user)

# ----------- JOB POSTING -----------
@app.route("/post_job", methods=["GET", "POST"])
def post_job():
    if "user_id" not in session or session["role"] != "employer":
        return redirect(url_for("login"))
    if request.method == "POST":
        title = request.form["title"]
        description = request.form["description"]
        company = request.form["company"]

        conn = get_db_connection()
        conn.execute("INSERT INTO jobs (title, description, company, posted_by) VALUES (?, ?, ?, ?)",
                     (title, description, company, session["user_id"]))
        conn.commit()
        conn.close()
        return redirect(url_for("home"))
    return render_template("post_job.html")

# ----------- APPLY FOR JOB -----------
@app.route("/apply/<int:job_id>", methods=["POST", "GET"])
def apply(job_id):
    if "user_id" not in session or session["role"] != "jobseeker":
        return redirect(url_for("login"))

    conn = get_db_connection()
    cur = conn.cursor()

    # check if already applied
    cur.execute("SELECT * FROM applications WHERE job_id=? AND user_id=?", (job_id, session["user_id"]))
    if cur.fetchone():
        conn.close()
        return "⚠️ You already applied!"

    # get user resume
    cur.execute("SELECT resume_path FROM users WHERE id=?", (session["user_id"],))
    resume = cur.fetchone()["resume_path"]

    cur.execute("INSERT INTO applications (job_id, user_id, resume_path) VALUES (?, ?, ?)", 
                (job_id, session["user_id"], resume))
    conn.commit()
    conn.close()
    return redirect(url_for("my_applications"))

# ----------- JOB SEEKER DASHBOARD -----------
@app.route("/my_applications")
def my_applications():
    if "user_id" not in session or session["role"] != "jobseeker":
        return redirect(url_for("login"))
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""SELECT jobs.title, jobs.company, jobs.description, applications.status
                   FROM applications 
                   JOIN jobs ON applications.job_id = jobs.id 
                   WHERE applications.user_id=?""", (session["user_id"],))
    apps = cur.fetchall()
    conn.close()
    return render_template("my_applications.html", applications=apps)

# ----------- EMPLOYER DASHBOARD -----------
@app.route("/dashboard")
def dashboard():
    if not session.get("user_id") or session.get("role") != "employer":
        return redirect(url_for("login"))

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, title FROM jobs WHERE posted_by=?", (session["user_id"],))
    jobs = cur.fetchall()

    applications = []
    for job in jobs:
        cur.execute("""SELECT a.id, u.name, u.email, j.title, a.resume_path, a.status
                       FROM applications a
                       JOIN users u ON a.user_id = u.id
                       JOIN jobs j ON a.job_id = j.id
                       WHERE j.id=?""", (job["id"],))
        applications.extend(cur.fetchall())
    conn.close()
    return render_template("dashboard.html", applications=applications)

@app.route("/update_status/<int:app_id>/<string:status>")
def update_status(app_id, status):
    if not session.get("user_id") or session.get("role") != "employer":
        return redirect(url_for("login"))

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE applications SET status=? WHERE id=?", (status, app_id))
    conn.commit()
    conn.close()
    return redirect(url_for("dashboard"))

# -------------------- MAIN --------------------
if __name__ == "__main__":
    init_db()
    app.run(debug=True)
