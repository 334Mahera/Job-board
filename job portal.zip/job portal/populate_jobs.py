import sqlite3

# Connect to your database
conn = sqlite3.connect("database.db")
cur = conn.cursor()

# Add an employer if not exists
cur.execute("INSERT OR IGNORE INTO users (id, name, email, password, role) VALUES (1, 'Admin Employer', 'employer1@example.com', 'password123', 'employer')")

# Add sample jobs
jobs = [
    ("Software Engineer", "Develop and maintain web applications", "TechCorp", 1),
    ("Data Analyst", "Analyze datasets and generate reports", "DataSolutions", 1),
    ("Marketing Intern", "Assist in digital marketing campaigns", "MarketMakers", 1),
    ("Frontend Developer", "Build user interfaces for web apps", "WebWorks", 1),
    ("Backend Developer", "Develop server-side logic", "CodeBase", 1)
]

cur.executemany("INSERT INTO jobs (title, description, company, posted_by) VALUES (?, ?, ?, ?)", jobs)

conn.commit()
conn.close()
print("Sample jobs added successfully!")
